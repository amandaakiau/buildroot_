#!/bin/sh

cp $BINARIES_DIR/boot.scr $TARGET_DIR/boot/boot.scr
